package homework2;
import java.util.Scanner;
public class Number4 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner myObj = new Scanner(System.in);
		String userName;
		System.out.println("Enter your order:");
		userName = myObj.nextLine(); 
	    switch (userName) {
	        case "a":
	        case "A":
	            System.out.println("Your order BayCha");
	            break;
	        case "b":
	        case "B":
	            System.out.println("Your order Ice Tea");
	            break;
	        case "c":
	        case "C":
	            System.out.println("Your order Soup");
	            break;
	        default:
	            System.out.println("Out of order..");
	            break;
	    }
	}
}
