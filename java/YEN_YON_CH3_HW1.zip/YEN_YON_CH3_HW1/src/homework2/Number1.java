package homework2;

public class Number1 {

	public static void main(String[] args) {
		int num =5;
		int factorial = 1;
		for(int i =1;i<=num;i++) {
			factorial = factorial*i;
		}
		System.out.print("Factorail number of "+num+" is: "+factorial);
	}
}
