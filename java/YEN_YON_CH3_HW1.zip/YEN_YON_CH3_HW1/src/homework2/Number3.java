package homework2;

public class Number3 {

	public static void main(String[] args) {
		int i = 1;
		int average = 0;
		int count = 0;
		do{
			if(i%2== 1) {
				average = average+i;
				count++;
			}
			i++;
		}while(i<=50);
		System.out.println("The average of odd number: "+average/count);
	}
}

