package homework2;

import java.util.Scanner;

public class Number5 {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner myObj = new Scanner(System.in);
		String userName;
		System.out.println("Enter A or a to display 10 entities per page");
		System.out.println("Enter B or b to display 20 entities per page");
		System.out.println("Enter C or c to display 50 entities per page");
		System.out.println("Enter D or d to display 100 entities per page");
		System.out.println("Enter E or e to display 200 entities per page");
		System.out.println("---------------------------------------------");
		System.out.println("Enter:");
		userName = myObj.nextLine(); 
		int a = 10;
		int b = 20;
		int c = 50;
		int d = 100;
		int e =200;
		int defaults =5;
		
	    switch (userName) {
	        case "a":
	        case "A":
		            System.out.println("Entities:150");
		            System.out.println("Entities To Display Per Page:"+a);
		            System.out.println("========================================");
		            for(int j = 1;j<=150/a;j++) {
		        	   System.out.print("|"+"page"+j+":"+a);
		           }
		           System.out.println("|");
		            break;
	        case "b":
	        case "B":
	        	 	System.out.println("Entities:150");
		            System.out.println("Entities To Display Per Page:"+b);
		            System.out.println("========================================");
		            for(int k = 1;k<=150/b;k++) {
		        	   System.out.print("|"+"page"+k+":"+b+"|"+"page8:"+a);
		           }
		           System.out.println("|");
		           break;
	        case "c":
	        case "C":
	        	 	System.out.println("Entities:150");
		            System.out.println("Entities To Display Per Page:"+c);
		            System.out.println("========================================");
		            for(int j = 1;j<=150/c;j++) {
		        	   System.out.print("|"+"page"+j+":"+c);
		            }
		            System.out.println("|");
		            break;
	        case "d":
	        case "D":
	        		System.out.println("Entities:150");
		            System.out.println("Entities To Display Per Page:"+d);
		            System.out.println("========================================");
		            for(int j = 1;j<=150/d;j++) {
		        	   System.out.print("|"+"page"+j+":"+d+"|"+"page2:"+c);
		            }
		            System.out.println("|");
		            break;
	        case "e":
	        case "E":
	        	 	System.out.println("Entities:150");
		            System.out.println("Entities To Display Per Page:"+e);
		            System.out.println("========================================");
		            if(e>150/e) {
		            	System.out.print("|"+"page1:"+(-c));
		            }
		            System.out.println("|");
		            break;
	        default:
	        	 	for(int j = 1;j<=150/defaults;j++) {
		        	   System.out.print("|"+"page"+j+":"+defaults);
	        	 	}
	        	 	System.out.println("|");
	        	 	break;
	    }
	}
}
