package homework1;

public class Number5 {

	public static void main(String[] args) {
		//number 5
		String str = "This is the most common way of creating string";  
        String replace_string = str.replace("string","STRING"); // Replace 'string' with 'STRING'  
        System.out.println("Original setence: "+str);
        System.out.println("Replaced sentence: "+replace_string);  

	}

}
