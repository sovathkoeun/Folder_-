package homework1;

public class Number3 {

	public static void main(String[] args) {
		//number 3
		String s ="www.google.com/";
		if (s.contains("/")) {
		    String s1 = s.replaceFirst("/", "/wep2020");
		    System.out.println(s1);
		}else {
			System.out.println(s+" does not end with /");
		}


	}

}
