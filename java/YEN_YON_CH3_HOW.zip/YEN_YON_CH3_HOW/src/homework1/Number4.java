package homework1;

public class Number4 {

	public static void main(String[] args) {
		//number 4
		String someString = "this is the most common way.";
		char someChar = 'o';
		int count = 0;
		  
		for (int i = 0; i < someString.length(); i++) {
		    if (someString.charAt(i) == someChar) {
		        count++;
		    }
		}
		
		System.out.println("There are "+count+" letter "+someChar+" in This the most common way.");

		
	}

}
