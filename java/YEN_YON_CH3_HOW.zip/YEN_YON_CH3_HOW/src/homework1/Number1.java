package homework1;

public class Number1 {

	public static void main(String[] args) {

		//number 1
		String string1 ="programing";
		String string2 ="homework";
		String string3 ="marker";
		
		String answer1 =string1.substring(0,string1.length()/2);
		String answer2 =string2.substring(0,string2.length()/2);
		String answer3 =string3.substring(0,string3.length()/2);
		
		System.out.println(answer1 +" is the first half of "+string1);
		System.out.println(answer2 +" is the first half of "+string2);
		System.out.println(answer3 +" is the first half of "+string3);
	}

}
