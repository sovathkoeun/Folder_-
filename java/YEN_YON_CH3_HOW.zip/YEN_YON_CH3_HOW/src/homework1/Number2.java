package homework1;

public class Number2 {

	public static void main(String[] args) {
		//number 2
		String a = "welcome";
		String first =a.substring(0,a.length()-3);
		String last = a.substring((a.length()-3),a.length()).toUpperCase();
		System.out.println("From "+a+" to "+first+last);
	}

}
