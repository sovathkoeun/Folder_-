<h2>Join Us</h2>
<p>We rely on the talents and dedicated human resources to develop our actions and
sustain our activities.</p><?php /**PATH C:\xampp\htdocs\Laravel\homework\homeworkrouteview\resources\views/pages/joinUs.blade.php ENDPATH**/ ?>