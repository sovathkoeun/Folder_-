<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Success Form</title>
    <style>
        body  {
        background-image: url("../images/register.jpg");
        background-size:cover;
        }
        table{
            font-weight: normal;
        }
</style>
</head>
<body>
    <div class="cotainer mt-5">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="alert alert-success">
                    <strong>Register success!!!</strong> Congratulation you can use the application.</div>
                    <form action="../pages_login/login.php" method ="post">
                        <button class="btn btn-primary btn-block">Log Out</button>
                    </form>
                </div>
            <div class="col-2"></div>
        </div>
     </div>


    <div class="container_table mt-5">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <ul class="list-group">
                    <li class="list-group-item"><strong>Username:</strong>
                            <?php 
                                session_start();
                                if(isset($_SESSION['name']) && !empty($_SESSION['name'])) {
                                        echo $_SESSION['name'];
                                    }
                             ?>

                    </li>
                    <li class="list-group-item"><strong>Password:</strong>
                            <?php 
                                    if(isset($_SESSION['pwd']) && !empty($_SESSION['pwd'])) {
                                        echo $_SESSION['pwd'];
                                    }
                             ?> 
                    </li>
                    <li class="list-group-item"><strong>Email:</strong>
                            <?php 
                                if(isset($_SESSION['email']) && !empty( $_SESSION['email'])) {
                                        echo $_SESSION['email'];
                                        }
                             ?>
                    </li>
                    <li class ="list-group-item"><strong>Message:</strong>
                         <?php 
                                if(isset( $_SESSION['message']) && !empty(  $_SESSION['message'])) {
                                echo  $_SESSION['message'];
                                }
                        ?>  

                    </li>
                </ul>

            </div>
            <div class="col-2"></div>
        </div>
     </div> 
</body>
</html>