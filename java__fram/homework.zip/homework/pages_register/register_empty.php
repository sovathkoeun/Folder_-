<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Not Yet</title>
    <style>
        body  {
        background-image: url("../images/register.jpg");
        background-size:cover;
        }
</style>
</head>
<body>
    <div class="cotainer mt-5">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <div class="alert alert-danger">
                    <strong>Fields Cannot Empty!</strong>
                    You should fill
                   <p> in all the fields.</p></div>
                    <form action="register.php" method ="post">
                        <button class="btn btn-primary btn-block">Go to Register</button>
                    </form>
                </div>
            <div class="col-4"></div>
        </div>
    </div>
</body>
</html>