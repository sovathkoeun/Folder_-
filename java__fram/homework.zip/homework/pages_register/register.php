<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <title>resgister</title>

    <style>
        body  {
        background-image: url("../images/register.jpg");
        background-size:cover;
        }
</style>
</head>
<body>
<div class="container mt-5">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <div class="card">
                    <div class="card-header text-center"><h2>Register Form</h2></div>
                    <div class="card-body">
                        <form action="../action/register_process.php" method ="post">
                            <div class="form-group">
                                <label>Username:</label>
                                <input type="text" name="username" class="form-control" placeholder="Username">
                            </div>
                            <div class="form-group">
                                <label>Password:</label>
                                <input type="password" name="password" class="form-control" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <label>Email:</label>
                                <input type="email" name="email" class="form-control" placeholder="email">
                            </div>
                           
                            <div class="form-group">
                                <label>Message:</label>
                                <textarea name="message" id="message" cols="30" rows="3" class="form-control" style ="resize:none"></textarea>
                            </div>
                           
                            <button type="submit" class="btn btn-info" name ="submit">Submit</button>
                            <button type="submit" class="btn btn-danger float-right" name ="back">Back to Login</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-4"></div>
        </div>
    </div>
</body>
</html>