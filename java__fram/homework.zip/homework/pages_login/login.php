<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <title>Login Form</title>

    <style>
body  {
  background-image: url("../images/login.jpg");
  background-size:corver;
  margin-top:90px;
}
</style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <div class="card">
                    <div class="card-header text-center"><h2>Login Form</h2></div>
                    <div class="card-body">
                        <form action="../action/login_process.php" method ="post">
                            <div class="form-group">
                                <label>Username:</label>
                                <input type="text" name="username" class="form-control" placeholder="Username">
                            </div>
                            <div class="form-group">
                                <label>Password:</label>
                                <input type="password" name="password" class="form-control" placeholder="Password">
                            </div>
                            
                            <button type="submit" class="btn btn-info" name ="login">Login</button>
                            <button type="submit" class="btn btn-danger float-right" name ="register">Register</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-4"></div>
        </div>
    </div>
</body>
</html>