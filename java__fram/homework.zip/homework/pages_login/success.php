<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Success Form</title>
    <style>
        body  {
        background-image: url("../images/login.jpg");
        margin-top:80px;
        
        }
</style>
</head>
<body>
    <div class="cotainer mt-5">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <div class="alert alert-success">
                    <strong>Login Success!!!</strong>Congratulation you 
                     <p> have done a great job.</p> </div>
                    <form action="login.php" method ="post">
                        <button class="btn btn-primary btn-block">Log Out</button>
                    </form>
                </div>
            <div class="col-4"></div>
        </div>
    </div>
</body>
</html>