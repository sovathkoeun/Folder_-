<?php 
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $message =$_POST['message'];
    if(empty($username) || empty($password)||empty($email) || empty($message)){
        header('Location:../pages_register/register_empty.php');
    }else{
        header('location:../pages_register/register_success.php');
        
    }
    session_start();
    $_SESSION['name'] =$username;
    $_SESSION['pwd'] = $password;
    $_SESSION['email'] = $email;
    $_SESSION['message'] = $message;
   


}else if(isset($_POST['back'])){
   header('Location:../pages_login/login.php');
}
?>