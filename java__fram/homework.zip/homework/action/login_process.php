<?php 
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if ($username==="admin" && $password==="password" ){
      header('Location:../pages_login/success.php');
    }else if(empty($username) || empty($password)){
        header('Location:../pages_login/Empty.php');
    }else{
        header('Location:../pages_login/erro.php');
    }
}else if(isset($_POST['register'])){
    header('Location:../pages_register/register.php');
}
?>